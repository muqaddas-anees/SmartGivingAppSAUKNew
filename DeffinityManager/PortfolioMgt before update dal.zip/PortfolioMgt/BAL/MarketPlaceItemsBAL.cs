﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeffinityManager.Portfolio.BAL
{
    public class MarketPlaceItemsBAL
    {
       // public static void MarketPlaceItemsBAL_

    }
}
