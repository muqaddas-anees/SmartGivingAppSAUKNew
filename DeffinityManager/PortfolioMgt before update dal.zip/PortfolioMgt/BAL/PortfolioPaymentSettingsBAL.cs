﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortfolioMgt.BAL
{
    public class PortfolioPaymentSettingsBAL
    {
        public static bool IsPaymentActive()
        {
            bool retval = false;
            try
            {
                if (System.Web.HttpContext.Current.Session["PayStatus"] == null)
                {
                    var payDetials = PortfolioMgt.BAL.PortfolioPaymentSettingsBAL.PortfolioPaymentSettingsBAL_SelectByCompany();
                    if (payDetials != null)
                    {
                        var mid = payDetials.Vendor.Trim();
                        if (mid.Length == 0)
                        {
                            retval = false;
                            sessionKeys.PayStatus = retval; //System.Web.HttpContext.Current.Session["PayStatus"] = retval;
                        }
                        else
                        {
                            retval = true;
                            sessionKeys.PayStatus = retval;
                        }
                    }
                }
                else
                {
                    retval = sessionKeys.PayStatus;
                }
              
            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }

            return retval;
        }

        public static void Clear_IsPaymentActive_Session()
        {
            System.Web.HttpContext.Current.Session["PayStatus"] = null;
        }

        public static bool PortfolioPaymentSettingsBAL_AddUpdate(PortfolioMgt.Entity.PortfolioPaymentSetting ps)
        {
            bool retval = false;
            IPortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting> pRep = new PortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting>();
            var p = pRep.GetAll().Where(o => o.PortfolioID == ps.PortfolioID).FirstOrDefault();
            if(p== null)
            {
                ps.LoggedBy = sessionKeys.UID;
                ps.LoggedDatetime = DateTime.Now;
                ps.CardFee = 3;
                pRep.Add(ps);
                if(ps.ID >0)
                retval = true;
            }
            else
            {
                p.Host = ps.Host;
                p.Notes = ps.Notes;
                p.Partner = ps.Partner;
                p.Password = ps.Password;
                p.PayType = ps.PayType;
                p.Username = ps.Username;
                p.Vendor = ps.Vendor;
                p.CardFee = ps.CardFee;
                p.consumerSecret = ps.consumerSecret;
                p.consumerKey = ps.consumerKey;
                pRep.Edit(p);
                retval = true;
            }
            return retval;
        }

        public static PortfolioMgt.Entity.PortfolioPaymentSetting PortfolioPaymentSettingsBAL_SelectByCompany()
        {
            
            IPortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting> pRep = new PortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting>();
            return pRep.GetAll().Where(o => o.PortfolioID == sessionKeys.PortfolioID).FirstOrDefault();
           
        }
        public static List<PortfolioMgt.Entity.PortfolioPaymentSetting> PortfolioPaymentSettingsBAL_SelectAll()
        {
            
            IPortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting> pRep = new PortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting>();
            return pRep.GetAll().ToList();

        }
        public static PortfolioMgt.Entity.PortfolioPaymentSetting PortfolioPaymentSettingsBAL_SelectByCompany(int portfolioid)
        {
            
            IPortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting> pRep = new PortfolioRepository<PortfolioMgt.Entity.PortfolioPaymentSetting>();
            return pRep.GetAll().Where(o => o.PortfolioID == portfolioid).FirstOrDefault();

        }
    }
}
