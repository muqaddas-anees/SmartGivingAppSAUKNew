﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PortfolioMgt.Entity;
using PortfolioMgt.DAL;

namespace PortfolioMgt.BAL
{
    
    public class PortfolioContactsTagsBAL
    {
        IPortfolioRepository<PortfolioContactsTag> pcRepository = null;

        public PortfolioContactsTagsBAL()
        {
            pcRepository = new PortfolioRepository<PortfolioContactsTag>();
        }

        public IEnumerable<PortfolioContactsTag> PortfolioContactsTags_SelectAll()
        {
            var pcCollection = pcRepository.GetAll().Where(o=>o.PortfolioID ==  sessionKeys.PortfolioID);
            var count = pcCollection.ToList().Count();
            //if count is zero insert default tags
            if(count == 0)
            {
                PortfolioContactsTags_Add("All Customers");
                //PortfolioContactsTags_Add("Designing");
                //PortfolioContactsTags_Add("");
            }

            return pcCollection;
        }
        public void PortfolioContactsTags_Add(PortfolioContactsTag pc)
        {
            if (pc != null)
            {
                var pcCollection = pcRepository.GetAll().Where(o => o.PortfolioID == sessionKeys.PortfolioID);

                //check name alredy exists
                if (pcCollection.Where(o => o.Tag.ToLower() == pc.Tag.ToLower()).Count() == 0)
                {
                    pcRepository.Add(pc);
                }
            }
        }
        public void PortfolioContactsTags_Add(string tagname)
        {
            PortfolioContactsTags_Add(new PortfolioContactsTag() { PortfolioID = sessionKeys.PortfolioID, Tag = tagname });
        }
    }
}
