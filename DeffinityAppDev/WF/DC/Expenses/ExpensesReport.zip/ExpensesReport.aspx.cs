﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DeffinityAppDev.WF.DC.Expenses
{
    public partial class ExpensesReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindUsers();
                BindGrid();
               
            }
        }
        private void BindUsers()
        {
            try
            {
                var jlist = (from p in UserMgt.BAL.ContractorsBAL.Contractor_SelectAdmins()
                             orderby p.ContractorName
                             select new { ID = p.ID, Text = p.ContractorName }).ToList();
                ddlUsers.DataSource = jlist;
                ddlUsers.DataTextField = "Text";
                ddlUsers.DataValueField = "ID";
                ddlUsers.DataBind();
                ddlUsers.Items.Insert(0, new ListItem("Please select...", "0"));
            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
        }
        private void BindGrid()
        {
            try
            {
                List<TimesheetMgt.Entity.v_TimeExpense> vlist = new List<TimesheetMgt.Entity.v_TimeExpense>();
                if (!String.IsNullOrEmpty(txtweekcommencedate.Text.Trim()) && (ddlUsers.SelectedValue != "0"))
                {
                    vlist = TimesheetMgt.BAL.TimeExpensesBAL.TimeExpensesBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).Where(o => Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim())) >= o.TimeExpensesDate && o.TimeExpensesDate <= Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim()))).Where(o => o.ContractorID == Convert.ToInt32(ddlUsers.SelectedValue)).OrderByDescending(o => o.TimeExpensesDate).ToList();
                }
                else if (!String.IsNullOrEmpty(txtweekcommencedate.Text.Trim()))
                    vlist = TimesheetMgt.BAL.TimeExpensesBAL.TimeExpensesBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).Where(o => Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim())) >= o.TimeExpensesDate && o.TimeExpensesDate <= Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim()))).OrderByDescending(o => o.TimeExpensesDate).ToList();
                else if (ddlUsers.SelectedValue != "0")
                    vlist = TimesheetMgt.BAL.TimeExpensesBAL.TimeExpensesBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).Where(o => o.ContractorID == Convert.ToInt32(ddlUsers.SelectedValue)).OrderByDescending(o => o.TimeExpensesDate).ToList();
                else
                    vlist = TimesheetMgt.BAL.TimeExpensesBAL.TimeExpensesBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).OrderByDescending(o => o.TimeExpensesDate).ToList();
                GridPartner.DataSource = vlist;
                GridPartner.DataBind();


            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
        }

        protected void btn_viewdate_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void GridPartner_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                // bool isChecked = ((CheckBox)e.Row.FindControl("chkSelect2")).Checked;
                var status = ((Label)e.Row.FindControl("lblStatusName")).Text;
                if (status == "Paid")
                { e.Row.BackColor = System.Drawing.Color.LightYellow; }

            }
        }
    }
}