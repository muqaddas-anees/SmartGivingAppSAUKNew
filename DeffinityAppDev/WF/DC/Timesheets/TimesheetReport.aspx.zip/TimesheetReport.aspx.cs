﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TimesheetMgt.Entity;

namespace DeffinityAppDev.WF.DC.Timesheets
{
    public partial class TimesheetReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindUsers();
                BindGrid();

            }
        }
        private void BindUsers()
        {
            try
            {
                var jlist = (from p in UserMgt.BAL.ContractorsBAL.Contractor_SelectAdmins()
                             orderby p.ContractorName
                             select new { ID = p.ID, Text = p.ContractorName }).ToList();
                ddlUsers.DataSource = jlist;
                ddlUsers.DataTextField = "Text";
                ddlUsers.DataValueField = "ID";
                ddlUsers.DataBind();
                ddlUsers.Items.Insert(0, new ListItem("Please select...", "0"));
            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
        }
        public string ChangeHoues(string GetHours)
        {

            string GetActivity = "";
            try
            {
                char[] comm1 = { '.' };
                string[] displayTime = GetHours.Split(comm1);


                GetActivity = displayTime[0] + ":" + displayTime[1];


            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
            return GetActivity;
        }
        public string ChangeTimeDisplay(string GetHours)
        {

            string GetActivity = "";
            try
            {
                char[] comm1 = { ':' };
                string[] displayTime = GetHours.Split(comm1);


                GetActivity = displayTime[0] + ":" + displayTime[1];


            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
            return GetActivity;
        }
        private void BindGrid()
        {
            try
            {
                List<TimesheetMgt.Entity.v_timesheetentry> vlist = new List<TimesheetMgt.Entity.v_timesheetentry>();

                if(!String.IsNullOrEmpty(txtweekcommencedate.Text.Trim()) && ddlUsers.SelectedValue != "0")
                {
                    vlist = TimesheetMgt.BAL.TimesheetEntryBAL.TimesheetBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).Where(o => Deffinity.Utility.StartOfDay( Convert.ToDateTime(txtweekcommencedate.Text.Trim())) >= o.DateEntered && o.DateEntered <= Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim()))).Where(o => o.ContractorID == Convert.ToInt32(ddlUsers.SelectedValue)).OrderByDescending(o => o.ContractorName).OrderByDescending(o => o.DateEntered).ToList();
                }
                else if (!String.IsNullOrEmpty(txtweekcommencedate.Text.Trim()))
                    vlist = TimesheetMgt.BAL.TimesheetEntryBAL.TimesheetBAL_SelectAll().Where(o => Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim())) >= o.DateEntered && o.DateEntered <= Deffinity.Utility.StartOfDay(Convert.ToDateTime(txtweekcommencedate.Text.Trim()))).OrderByDescending(o => o.ContractorName).OrderByDescending(o => o.DateEntered).ToList();
                else if (ddlUsers.SelectedValue != "0")
                    vlist = TimesheetMgt.BAL.TimesheetEntryBAL.TimesheetBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).Where(o => o.ContractorID == Convert.ToInt32(ddlUsers.SelectedValue)).OrderByDescending(o => o.ContractorName).OrderByDescending(o => o.DateEntered).ToList();
                else
                    vlist = TimesheetMgt.BAL.TimesheetEntryBAL.TimesheetBAL_SelectAll().Where(o => o.PorfolioID == sessionKeys.PortfolioID).OrderByDescending(o => o.DateEntered).ToList();
                GridPartner.DataSource = vlist;
                GridPartner.DataBind();


            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
        }

        protected void btn_viewdate_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void GridPartner_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    // bool isChecked = ((CheckBox)e.Row.FindControl("chkSelect2")).Checked;
                    var status = ((Label)e.Row.FindControl("lblStatusName")).Text;
                    if (status == "Approved")
                    { e.Row.BackColor = System.Drawing.Color.LightYellow; }
                    //v_timesheetentry objList = e.Row.DataItem as v_timesheetentry;
                    //if (objList != null)
                    //{

                    //    Label lblGridEndTime = (Label)e.Row.FindControl("lblGridEndTime");
                    //    Label lblGridStartTime = (Label)e.Row.FindControl("lblGridStartTime");
                    //    //Button btnStop = (Button)e.Row.FindControl("btnStop");
                    //    //index 19,20 are StartTime and end time
                    //    LogExceptions.LogException("todate: " + objList.totime.ToString());
                    //    if (objList.totime.HasValue && objList.fromtime.HasValue)
                    //    {
                    //        lblGridEndTime.Text = objList.totime.Value.ToString().Substring(0, 5);
                    //        lblGridStartTime.Text = objList.fromtime.Value.ToString().Substring(0, 5);
                    //        if (lblGridStartTime.Text == lblGridEndTime.Text)
                    //        {
                    //            lblGridEndTime.Text = "";
                    //            lblGridStartTime.Text = "Started at " + objList.fromtime.Value.ToString().Substring(0, 5);
                    //            //btnStop.Visible = true;
                    //        }
                    //        else
                    //        {
                    //            //btnStop.Visible = false;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        lblGridEndTime.Text = string.Empty;
                    //        lblGridStartTime.Text = string.Empty;
                    //    }


                    //}


                }

            
            }
            catch (Exception ex)
            {
                LogExceptions.WriteExceptionLog(ex);
            }
        }
    }
}