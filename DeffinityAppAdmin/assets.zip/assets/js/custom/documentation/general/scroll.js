/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!********************************************************!*\
  !*** ../src/js/custom/documentation/general/scroll.js ***!
  \********************************************************/


// Class definition
var KTGeneralScrollDemos = function() {
    // Private functions
    var _exampleBasic = function() {
        
    }

    return {
        // Public Functions
        init: function() {
            _exampleBasic();
        }
    };
}();

// On document ready
KTUtil.onDOMContentLoaded(function() {
    KTGeneralScrollDemos.init();
});

/******/ })()
;
//# sourceMappingURL=scroll.js.map